# Dewasi SMM WebView Android app — consolidated starter

Brand: website-matching red `#E51E25`, white, light gray, dark text.
Website: https://dewasismm.com

## Included
- WebView opens the existing website
- Animated in-app splash while initial page loads
- Refresh toolbar button and pull-to-refresh
- Back navigation through web history; exit confirmation Yes/No when there is no history
- Offline error screen with **no Retry button**
- While the offline error screen is visible only, check connectivity every 3 seconds; reload once connectivity returns
- No automatic reload while normal website pages, forms, orders, or payments are open
- External HTTPS links are handled inside the app; non-web schemes such as UPI/tel/mailto are handed to Android apps where supported
- App icon and version metadata
- Update-check scaffold (requires hosted JSON configuration)
- Notification permission/settings scaffold and setup instructions
- GitHub Actions workflow to build a debug APK from the cloud

## Important limitations
This is a starter project and **has not been compiled, installed, or tested in this environment**. Do not claim it is production-ready until tested on the actual website and device.
- Push notifications require Firebase project setup, Android app registration, `google-services.json`, and a trusted way to send messages. No server credentials belong in the APK.
- In-app update popup requires a hosted `app_update.json` file. Android cannot silently update itself; the update link must point to a trusted download/distribution page.
- Login/session behavior depends on Dewasi SMM website cookies and must be tested. The app does not collect or store passwords separately.
- Payment gateway redirects, UPI apps, file uploads/downloads, and OAuth flows need real-device testing.
- SSL certificate errors are not bypassed.
- The webview_flutter plugin provides cookie handling via Android WebView's cookie store, but session expiry/logout must be verified against the live panel.
- Connectivity status is not a guarantee that the internet can reach the website; main-frame load errors are also handled.

## Build from an Android phone
1. Download and extract this ZIP on your phone.
2. In your existing GitHub repository `dewasi-smm-android`, upload/replace files from this folder while preserving folder paths. Do not upload only the ZIP.
3. Commit changes to the `main` branch.
4. Open Actions and run `Build Dewasi SMM WebView APK`.
5. After success, download artifact `dewasi-smm-webview-apk` and extract the APK.

## Remote update config example
Host a JSON file at the URL set in `lib/app_config.dart`, for example:
`{"latestVersionCode":2,"minimumVersionCode":1,"versionName":"1.0.1","updateUrl":"https://dewasismm.com/app-download","message":"A new version is available."}`
Change version codes and URL only after a real release is available.
