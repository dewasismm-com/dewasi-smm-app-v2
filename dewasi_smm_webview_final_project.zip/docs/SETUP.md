# Setup notes

## Push notifications
The project initializes local notification support only. True push notifications require:
1. Create a Firebase project at https://console.firebase.google.com/
2. Register Android package `com.example.dewasi_smm_webview` (confirm generated application ID in Android project first).
3. Add the generated `google-services.json` in `android/app/`.
4. Configure the Google Services Gradle plugin as directed by current Firebase Flutter setup docs.
5. Add Firebase Messaging dependency and permission/token handling, then configure a trusted server or Firebase console to send notifications.
Never embed Firebase service-account credentials or server keys in the APK.
Until this setup is complete, push notifications are not functional.

## In-app updates
Host JSON at the URL configured in `lib/app_config.dart`. Example:
`{"latestVersionCode":2,"minimumVersionCode":1,"versionName":"1.0.1","updateUrl":"https://dewasismm.com/app-download","message":"A new version is available."}`
Set `updateConfigUrl` to that hosted JSON URL. Ensure `updateUrl` is a real trusted download page. Mandatory update blocks dismissing the dialog but cannot force-install the APK.

## App icon / package name
A starter icon is in `assets/app_icon.png`. A generated Android project must apply it as a launcher icon separately if a branded launcher icon is needed; this starter PNG is also a source asset. The generated default launcher icon may remain until adaptive launcher icon files are configured.

## Testing required
- login/logout and cookie persistence
- order submission, form inputs, file upload/download
- UPI/payment app redirects and return path
- back history and exit dialog
- offline screen and reconnection
- notification permission and actual push delivery
- update JSON, optional and mandatory update behavior
