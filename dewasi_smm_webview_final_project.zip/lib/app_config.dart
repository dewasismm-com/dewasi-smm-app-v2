class AppConfig {
  static const websiteUrl = 'https://dewasismm.com';
  static const brandRed = 0xFFE51E25;

  // Host an update JSON here before expecting the update popup to work.
  // Example JSON is documented in README.md. Leave blank to disable update checks.
  static const updateConfigUrl = '';
}
