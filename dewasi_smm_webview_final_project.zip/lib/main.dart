import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'app_config.dart';

const Color brandRed = Color(AppConfig.brandRed);
const Color lightGray = Color(0xFFF5F5F5);
const Color darkText = Color(0xFF222222);

final FlutterLocalNotificationsPlugin localNotifications =
    FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.white,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.white,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const DewasiApp());
}

class DewasiApp extends StatelessWidget {
  const DewasiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Dewasi SMM',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: brandRed),
          scaffoldBackgroundColor: Colors.white,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.white,
            foregroundColor: darkText,
            surfaceTintColor: Colors.white,
            elevation: 0,
          ),
          useMaterial3: true,
        ),
        home: const WebViewHome(),
      );
}

class WebViewHome extends StatefulWidget {
  const WebViewHome({super.key});
  @override
  State<WebViewHome> createState() => _WebViewHomeState();
}

class _WebViewHomeState extends State<WebViewHome>
    with SingleTickerProviderStateMixin {
  late final WebViewController _web;
  late final AnimationController _splashAnimation;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  Timer? _offlineTimer;
  bool _initialLoading = true;
  bool _offlinePageVisible = false;
  bool _mainFrameError = false;
  bool _loading = false;
  bool _showExitDialog = false;
  bool _updateChecked = false;
  int _progress = 0;
  String? _errorText;
  DateTime? _lastOfflineReload;

  @override
  void initState() {
    super.initState();
    _splashAnimation = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
    _initNotifications();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (value) {
          if (!mounted) return;
          setState(() {
            _progress = value;
            _loading = value < 100;
            if (value >= 100) {
              _initialLoading = false;
              _offlinePageVisible = false;
              _mainFrameError = false;
            }
          });
        },
        onPageStarted: (_) {
          if (!mounted) return;
          setState(() {
            _loading = true;
            _mainFrameError = false;
            _offlinePageVisible = false;
            _errorText = null;
          });
        },
        onPageFinished: (_) {
          if (!mounted) return;
          setState(() {
            _loading = false;
            _initialLoading = false;
            _offlinePageVisible = false;
            _mainFrameError = false;
          });
          if (!_updateChecked) {
            _updateChecked = true;
            _checkForUpdate();
          }
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() {
              _loading = false;
              _initialLoading = false;
              _mainFrameError = true;
              _offlinePageVisible = true;
              _errorText = 'Internet connection nahi mil raha.';
            });
            _startOfflinePolling();
          }
        },
        onNavigationRequest: (request) {
          final uri = Uri.tryParse(request.url);
          if (uri == null) return NavigationDecision.prevent;
          if (uri.scheme == 'https' || uri.scheme == 'http') {
            final host = uri.host.toLowerCase();
            final internal = host == 'dewasismm.com' ||
                host.endsWith('.dewasismm.com');
            if (internal) return NavigationDecision.navigate;
            // Keep regular web links in the WebView for common login/payment return flows.
            // Other HTTPS links can be opened externally only when explicitly non-web scheme.
            return NavigationDecision.navigate;
          }
          _openExternal(uri);
          return NavigationDecision.prevent;
        },
      ))
      ..loadRequest(Uri.parse(AppConfig.websiteUrl));

    _connectivitySubscription =
        Connectivity().onConnectivityChanged.listen((results) {
      if (_offlinePageVisible && _hasNetwork(results)) {
        _reloadAfterConnectivityReturns();
      }
    });
  }

  bool _hasNetwork(List<ConnectivityResult> results) =>
      results.any((r) => r != ConnectivityResult.none);

  Future<void> _initNotifications() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    try {
      await localNotifications.initialize(settings);
      // Local notifications are initialized only. Push requires Firebase configuration.
    } catch (_) {}
  }

  Future<void> _checkForUpdate() async {
    if (AppConfig.updateConfigUrl.isEmpty) return;
    try {
      final response = await http
          .get(Uri.parse(AppConfig.updateConfigUrl))
          .timeout(const Duration(seconds: 5));
      if (response.statusCode != 200 || !mounted) return;
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final info = await PackageInfo.fromPlatform();
      final currentCode = int.tryParse(info.buildNumber) ?? 1;
      final latestCode = (data['latestVersionCode'] as num?)?.toInt() ?? currentCode;
      final minimumCode = (data['minimumVersionCode'] as num?)?.toInt() ?? 1;
      if (latestCode > currentCode && mounted) {
        final mandatory = currentCode < minimumCode;
        showDialog<void>(
          context: context,
          barrierDismissible: !mandatory,
          builder: (context) => PopScope(
            canPop: !mandatory,
            child: AlertDialog(
              title: Text(mandatory ? 'Update required' : 'Update available'),
              content: Text((data['message'] as String?) ??
                  'Dewasi SMM ka naya version available hai.'),
              actions: [
                if (!mandatory)
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Later'),
                  ),
                FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: brandRed),
                  onPressed: () async {
                    final url = Uri.tryParse((data['updateUrl'] as String?) ?? '');
                    if (url != null) await launchUrl(url, mode: LaunchMode.externalApplication);
                  },
                  child: const Text('Update now'),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {}
  }

  Future<void> _openExternal(Uri uri) async {
    if (uri.scheme == 'tel' || uri.scheme == 'mailto' ||
        uri.scheme == 'upi' || uri.scheme == 'intent' ||
        uri.scheme == 'sms') {
      try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) {}
    } else if (uri.scheme == 'https' || uri.scheme == 'http') {
      try { await launchUrl(uri, mode: LaunchMode.externalApplication); } catch (_) {}
    }
  }

  void _startOfflinePolling() {
    _offlineTimer?.cancel();
    _offlineTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      if (!_offlinePageVisible || !mounted) {
        _offlineTimer?.cancel();
        return;
      }
      final results = await Connectivity().checkConnectivity();
      if (_hasNetwork(results)) _reloadAfterConnectivityReturns();
    });
  }

  void _reloadAfterConnectivityReturns() {
    if (!_offlinePageVisible || !mounted) return;
    final now = DateTime.now();
    if (_lastOfflineReload != null &&
        now.difference(_lastOfflineReload!) < const Duration(seconds: 4)) return;
    _lastOfflineReload = now;
    _offlineTimer?.cancel();
    setState(() {
      _offlinePageVisible = false;
      _mainFrameError = false;
      _loading = true;
      _progress = 0;
    });
    _web.loadRequest(Uri.parse(AppConfig.websiteUrl));
  }

  Future<void> _refresh() async {
    if (_offlinePageVisible) return; // Never manually reload from the offline screen.
    await _web.reload();
  }

  Future<void> _handleBack() async {
    if (await _web.canGoBack()) {
      await _web.goBack();
      return;
    }
    if (!mounted) return;
    final exit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Exit Dewasi SMM?'),
        content: const Text('Kya aap app se bahar nikalna chahte hain?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('No'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: brandRed),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Yes'),
          ),
        ],
      ),
    );
    if (exit == true) SystemNavigator.pop();
  }

  @override
  void dispose() {
    _offlineTimer?.cancel();
    _connectivitySubscription?.cancel();
    _splashAnimation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) {
          if (!didPop) _handleBack();
        },
        child: Scaffold(
          appBar: AppBar(
            title: const Row(children: [
              Icon(Icons.trending_up, color: brandRed),
              SizedBox(width: 8),
              Text('DEWASI SMM',
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ]),
            actions: [
              IconButton(
                tooltip: 'Refresh',
                onPressed: _offlinePageVisible ? null : _refresh,
                icon: const Icon(Icons.refresh),
              ),
            ],
            bottom: _loading && !_offlinePageVisible
                ? PreferredSize(
                    preferredSize: const Size.fromHeight(3),
                    child: LinearProgressIndicator(
                      value: _progress > 0 ? _progress / 100 : null,
                      color: brandRed,
                      backgroundColor: lightGray,
                    ),
                  )
                : null,
          ),
          body: Stack(children: [
            if (!_offlinePageVisible)
              RefreshIndicator(
                color: brandRed,
                onRefresh: _refresh,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.zero,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height -
                          MediaQuery.of(context).padding.top -
                          kToolbarHeight,
                      child: WebViewWidget(controller: _web),
                    ),
                  ],
                ),
              ),
            if (_offlinePageVisible)
              Positioned.fill(
                child: Container(
                  color: lightGray,
                  padding: const EdgeInsets.all(28),
                  child: Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.wifi_off, color: brandRed, size: 58),
                      const SizedBox(height: 16),
                      const Text('No Internet Connection',
                          style: TextStyle(
                              fontSize: 21, fontWeight: FontWeight.bold, color: darkText)),
                      const SizedBox(height: 8),
                      const Text(
                        'Internet connection ka wait kar rahe hain…',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.black54),
                      ),
                      const SizedBox(height: 18),
                      const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(color: brandRed, strokeWidth: 2.5),
                      ),
                    ]),
                  ),
                ),
              ),
            if (_initialLoading)
              Positioned.fill(
                child: Container(
                  color: Colors.white,
                  child: Center(
                    child: AnimatedBuilder(
                      animation: _splashAnimation,
                      builder: (context, child) => Transform.scale(
                        scale: 0.94 + (_splashAnimation.value * 0.08),
                        child: child,
                      ),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                          width: 92,
                          height: 92,
                          decoration: BoxDecoration(
                            color: brandRed,
                            borderRadius: BorderRadius.circular(26),
                          ),
                          child: const Icon(Icons.trending_up, color: Colors.white, size: 56),
                        ),
                        const SizedBox(height: 18),
                        const Text('DEWASI SMM',
                            style: TextStyle(
                                fontSize: 23, fontWeight: FontWeight.w900, color: darkText)),
                        const SizedBox(height: 16),
                        const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(color: brandRed, strokeWidth: 2.5),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
          ]),
        ),
      );
}
